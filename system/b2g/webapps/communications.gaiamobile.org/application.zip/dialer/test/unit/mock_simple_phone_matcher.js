var MockSimplePhoneMatcher = {
  sanitizedNumber: function(number) {
    return number;
  }
};
