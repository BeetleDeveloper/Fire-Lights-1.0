'use strict';

var MockWifiManager = {
  scan: function() {}
};

var MockWifiUI = {
  renderNetworks: function() {}
};
