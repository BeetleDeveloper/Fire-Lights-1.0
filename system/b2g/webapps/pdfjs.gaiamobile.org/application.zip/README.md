Please **DO NOT** make changes to any files in the content directory.
pdf.js is maintained in a separate repository, and they should all come from upstream.

https://github.com/mozilla/pdf.js
