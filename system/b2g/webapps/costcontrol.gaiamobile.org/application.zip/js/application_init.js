'use strict';

CostControlApp.init();
