'use strict';

ConfigManager.setConfig({});
